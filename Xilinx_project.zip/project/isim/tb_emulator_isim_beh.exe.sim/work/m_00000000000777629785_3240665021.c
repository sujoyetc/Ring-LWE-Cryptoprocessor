/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xcb73ee62 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/polynomial multiplication/LWE_SCA/RLWE_q7681_distribution/source/datapath_top.v";



static void Always_83_0(char *t0)
{
    char t6[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;

LAB0:    t1 = (t0 + 5676U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(83, ng0);
    t2 = (t0 + 5872);
    *((int *)t2) = 1;
    t3 = (t0 + 5704);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(84, ng0);

LAB5:    xsi_set_current_line(85, ng0);
    t4 = (t0 + 1152U);
    t5 = *((char **)t4);
    t4 = (t0 + 3404);
    xsi_vlogvar_wait_assign_value(t4, t5, 0, 0, 9, 0LL);
    xsi_set_current_line(85, ng0);
    t2 = (t0 + 1244U);
    t3 = *((char **)t2);
    t2 = (t0 + 3496);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 7, 0LL);
    xsi_set_current_line(85, ng0);
    t2 = (t0 + 1336U);
    t3 = *((char **)t2);
    t2 = (t0 + 3588);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 4, 0LL);
    xsi_set_current_line(85, ng0);
    t2 = (t0 + 1428U);
    t3 = *((char **)t2);
    t2 = (t0 + 3680);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    xsi_set_current_line(86, ng0);
    t2 = (t0 + 1520U);
    t3 = *((char **)t2);
    t2 = (t0 + 3864);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);
    xsi_set_current_line(87, ng0);
    t2 = (t0 + 1612U);
    t3 = *((char **)t2);
    t2 = (t0 + 3772);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 2, 0LL);
    xsi_set_current_line(88, ng0);
    t2 = (t0 + 2164U);
    t3 = *((char **)t2);
    t2 = (t0 + 2072U);
    t4 = *((char **)t2);
    t2 = (t0 + 1980U);
    t5 = *((char **)t2);
    t2 = (t0 + 1888U);
    t7 = *((char **)t2);
    t2 = (t0 + 1796U);
    t8 = *((char **)t2);
    xsi_vlogtype_concat(t6, 5, 5, 5U, t8, 1, t7, 1, t5, 1, t4, 1, t3, 1);
    t2 = (t0 + 4508);
    xsi_vlogvar_wait_assign_value(t2, t6, 0, 0, 1, 0LL);
    t9 = (t0 + 4324);
    xsi_vlogvar_wait_assign_value(t9, t6, 1, 0, 1, 0LL);
    t10 = (t0 + 4232);
    xsi_vlogvar_wait_assign_value(t10, t6, 2, 0, 1, 0LL);
    t11 = (t0 + 4140);
    xsi_vlogvar_wait_assign_value(t11, t6, 3, 0, 1, 0LL);
    t12 = (t0 + 4048);
    xsi_vlogvar_wait_assign_value(t12, t6, 4, 0, 1, 0LL);
    xsi_set_current_line(89, ng0);
    t2 = (t0 + 2624U);
    t3 = *((char **)t2);
    t2 = (t0 + 2532U);
    t4 = *((char **)t2);
    t2 = (t0 + 2440U);
    t5 = *((char **)t2);
    t2 = (t0 + 2716U);
    t7 = *((char **)t2);
    t2 = (t0 + 2348U);
    t8 = *((char **)t2);
    t2 = (t0 + 1704U);
    t9 = *((char **)t2);
    t2 = (t0 + 2256U);
    t10 = *((char **)t2);
    t2 = (t0 + 2808U);
    t11 = *((char **)t2);
    xsi_vlogtype_concat(t6, 17, 17, 8U, t11, 3, t10, 2, t9, 1, t8, 2, t7, 3, t5, 2, t4, 2, t3, 2);
    t2 = (t0 + 4968);
    xsi_vlogvar_wait_assign_value(t2, t6, 0, 0, 2, 0LL);
    t12 = (t0 + 4876);
    xsi_vlogvar_wait_assign_value(t12, t6, 2, 0, 2, 0LL);
    t13 = (t0 + 4784);
    xsi_vlogvar_wait_assign_value(t13, t6, 4, 0, 2, 0LL);
    t14 = (t0 + 5060);
    xsi_vlogvar_wait_assign_value(t14, t6, 6, 0, 3, 0LL);
    t15 = (t0 + 4692);
    xsi_vlogvar_wait_assign_value(t15, t6, 9, 0, 2, 0LL);
    t16 = (t0 + 3956);
    xsi_vlogvar_wait_assign_value(t16, t6, 11, 0, 1, 0LL);
    t17 = (t0 + 4600);
    xsi_vlogvar_wait_assign_value(t17, t6, 12, 0, 2, 0LL);
    t18 = (t0 + 5152);
    xsi_vlogvar_wait_assign_value(t18, t6, 14, 0, 3, 0LL);
    goto LAB2;

}


extern void work_m_00000000000777629785_3240665021_init()
{
	static char *pe[] = {(void *)Always_83_0};
	xsi_register_didat("work_m_00000000000777629785_3240665021", "isim/tb_emulator_isim_beh.exe.sim/work/m_00000000000777629785_3240665021.didat");
	xsi_register_executes(pe);
}
