The following files were generated for 'ram_load' in directory 
/volume1/scratch/ssinharo/polymul/n_512/3-stage_1051649_instructions/ipcore_dir/

dist_mem_gen_ds322.pdf:
   Please see the core data sheet.

dist_mem_gen_readme.txt:
   Text file indicating the files generated and how they are used.

ram_load.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

ram_load.gise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

ram_load.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

ram_load.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

ram_load.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

ram_load.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

ram_load.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

ram_load.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

ram_load.xise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

ram_load_readme.txt:
   Text file indicating the files generated and how they are used.

ram_load_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.

ram_load_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

