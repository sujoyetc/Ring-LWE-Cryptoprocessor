The following files were generated for 'LUT_RAM' in directory 
D:\polynomial multiplication\verilog\FFT_pipelined\n_512\3-stage_1051649\ipcore_dir\

LUT_RAM.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

LUT_RAM.gise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

LUT_RAM.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

LUT_RAM.sym:
   Please see the core data sheet.

LUT_RAM.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

LUT_RAM.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

LUT_RAM.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

LUT_RAM.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

LUT_RAM.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

LUT_RAM.xise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

LUT_RAM_readme.txt:
   Text file indicating the files generated and how they are used.

LUT_RAM_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.

dist_mem_gen_ds322.pdf:
   Please see the core data sheet.

dist_mem_gen_readme.txt:
   Text file indicating the files generated and how they are used.

LUT_RAM_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

